<script id="tmpl-pinTemplate" type="text/template">
	<div class="map-marker type-{{{ data.term }}}"><i class="{{{ data.icon }}}"></i></div>
</script>
