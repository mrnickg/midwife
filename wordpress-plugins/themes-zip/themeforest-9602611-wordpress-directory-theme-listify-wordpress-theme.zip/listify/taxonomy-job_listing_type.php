<?php
/**
 * The template for displaying job listing taxonomies.
 *
 * @package Listify
 */

locate_template( array( 'archive-job_listing.php' ), true );