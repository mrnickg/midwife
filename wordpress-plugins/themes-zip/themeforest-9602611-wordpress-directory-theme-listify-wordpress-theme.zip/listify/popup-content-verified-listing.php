<h2 class="popup-title"><?php _e( 'Verified Listing', 'listify' ); ?></h2>

<?php printf( apply_filters( 'listify_verified_listing_message', __( 'This listing is being maintained by its rightful owner.', 'listify' ) ) ); ?>
