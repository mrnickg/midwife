<?php
/**
 *
 */
?>

<?php do_action( 'listify_map_before' ); ?>

<div class="job_listings-map-wrapper">
	<?php do_action( 'listify_map_above' ); ?>

	<div class="job_listings-map">
		<div id="job_listings-map-canvas"></div>
	</div>

	<?php do_action( 'listify_map_below' ); ?>
</div>

<?php do_action( 'listify_map_after' ); ?>