(function() {
  jQuery(function($) {
    return $('.share-email').click(function(e) {
      return $.magnificPopup.close();
    });
  });

}).call(this);

//# sourceMappingURL=jetpack.js.map
