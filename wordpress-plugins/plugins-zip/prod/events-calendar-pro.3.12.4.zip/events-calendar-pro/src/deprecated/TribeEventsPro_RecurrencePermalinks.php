<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__Recurrence_Permalinks' );


	class TribeEventsPro_RecurrencePermalinks extends Tribe__Events__Pro__Recurrence_Permalinks {

	}