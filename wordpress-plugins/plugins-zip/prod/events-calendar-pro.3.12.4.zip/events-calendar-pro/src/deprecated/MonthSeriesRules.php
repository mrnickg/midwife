<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__Date_Series_Rules__Month' );


	class MonthSeriesRules extends Tribe__Events__Pro__Date_Series_Rules__Month {

	}