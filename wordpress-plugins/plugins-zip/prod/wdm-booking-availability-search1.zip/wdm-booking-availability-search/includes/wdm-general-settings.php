<form id="general-settings">
	<table class="form-table">
		<tbody>
			<tr valign="top">
				<th scope="row">Mode of charging:</th>
				<td>
					<select id="mode-of-charging" name="action">
						<option selected="selected" value="1">Days</option>
						<option value="0">Nights</option>

					</select>
					<br>
					<span class="bks_info">Mode of charging the customers.</span>
					<br>

				</td>
			</tr>
			<tr><td>
					<input type='button' id='mode-of-charging-submit' class='button button-primary' value='Save Changes'>
				</td></tr>
		</tbody>
	</table>
</form>

