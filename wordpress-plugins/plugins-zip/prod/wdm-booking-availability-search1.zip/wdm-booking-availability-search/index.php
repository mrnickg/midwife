<?php
echo "Silence is golden!Shhhh";