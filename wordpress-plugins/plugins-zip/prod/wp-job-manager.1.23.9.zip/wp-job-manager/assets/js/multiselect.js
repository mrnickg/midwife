jQuery(function(){
	jQuery( '.job-manager-multiselect' ).chosen({ search_contains: true });
});